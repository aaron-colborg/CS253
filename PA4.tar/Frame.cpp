#include <Frame.h>
#include <vector>
#include <iostream> 
using std::vector;
using std::cout;

Frame::Frame(vector<Point3D>& passedVector){
	poseVector = passedVector;
}

Frame::~Frame(){
	poseVector.clear();
}

void Frame::spineFix(double xAv,double yAv,double zAv){
	for(unsigned int i = 0; i  < poseVector.size(); i++){
		poseVector[i].allignSpine(xAv,yAv,zAv);
	}
}

double Frame::maxFrame(){
	double max = 0;	
	for(unsigned int i = 0; i < poseVector.size(); i++){
		double temp = 0;
				temp = poseVector[i].X();
				
				if(temp < 0){
					temp *= -1;
					if(temp > max){
						max = temp;
					}
				}
				else if(temp > max){
					max = temp;
				}
				//cout << "Max in Frame: " << max << std::endl;
				
				temp = poseVector[i].Y();
				if(temp < 0){
					temp *= -1;
					if(temp > max){
						max = temp;
					}
				}
				else if(temp > max){
					max = temp;
				}
				//cout << "Max in Frame: " << max << std::endl;

				temp = poseVector[i].Z();
				if(temp < 0){
					temp *= -1;
					if(temp > max){
						max = temp;
					}
				}
				else if(temp > max){
					max = temp;
				}
				//cout << "Max in Frame: " << max << std::endl;
	}
	return max;	
}

void Frame::reScale(double scale){
	for(unsigned int i = 0; i < poseVector.size(); i++){
		poseVector[i].scalePoints(scale);
	}
}


