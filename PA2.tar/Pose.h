#ifndef POSE_H
#define POSE_H

#include <vector>

class Pose{
 public:
	inline int vectorSize(){return poseVector.size();}
	inline void pushVector(vector<Point3D> myVector){poseVector = myVector;}
	inline vector<Point3D> retVector(){return poseVector;}
 protected:
    vector<Point3D> poseVector;
	
};

#endif //POSE_H
	

