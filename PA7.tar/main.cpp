// CS253_P1.cpp : Defines the entry point for the console application.
//
#include <Point3D.h>
//#include <PoseDisplay.h>
#include <Frame.h>
#include <FullVideo.h>
#include <Table.h>
//#include <stdafx.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iterator>
#include <math.h>
#include <stdlib.h>
#include <algorithm>
#include <cmath>
using std::max_element;
using std::sort;
using std::string;
using std::cout;
using std::istream;
using std::ifstream;
using std::ostream;
using std::ofstream;
using std::vector;
#include <ctime>
double vectorMin(vector<double>& passed);
double frameDistance(vector<Point3D>& frame, vector<Point3D>& frame2);
FullVideo normalizeFile(ifstream& myFile);
vector<vector<double> > distanceCalc(string arg, FullVideo& video1, FullVideo& video2);
double squaredDistance(vector<Point3D>& frame, vector<Point3D>& frame2);
double medDistance(vector<Point3D>& frame, vector<Point3D>& frame2);
double maxDistance(vector<Point3D>& frame, vector<Point3D>& frame2);
int indexOfMin(double min, vector<double>& results);

int main(int argc, char* argv[])
{		
	//std::clock_t    start;
	//start = std::clock();
	//FILE I/O/////////////////////////////////////////////////////////////
	// check for the correct number of arguments
	ifstream inFile;
	   
	string argString;

	if (argc < 4) {	
		std::cerr << "Too few arguments" << std::endl;
		return -1;
	}
	//////FILE 1 I/O
	inFile.open(argv[1]);
	//check if inFile exists and is openable
	if (inFile.is_open()) {
	}
	else {
		std::cerr << "Cannot Open file.\n";
		return -1;
	}
	//normalize File1
	FullVideo video1 = normalizeFile(inFile);
	if(video1.size() != 0){
	}
	else{
		return -1;
	}
	

	argString = argv[argc-1];
	vector<double> resultsVector;
	int fileCount = 2;
for(int i = 0; i < argc-2; i++){
	if(fileCount > (argc-2)){
		double min = vectorMin(resultsVector);
		int resIndex = indexOfMin(min,resultsVector);	
		cout << argv[resIndex+2] << std::endl;
		return 0;
	}
	ifstream secondInFile;	
	secondInFile.open(argv[fileCount]);
	fileCount++;

	//check if inFile exists and is openable
	if (secondInFile.is_open()) {
		//Testing purposes only
		//cout << "File is open.\n";
	}
	else {
		std::cerr << "Cannot Open file.\n";
		return -1;
	}

	//Finished File I/O, now parse line by line and store doubles into vector
	//POINTER YOU MUST DELETE
	FullVideo video2 = normalizeFile(secondInFile);
	//cout << "2: " << video2.size() << " 1: " << video1.size() << std::endl;
	
	if(video2.size() > video1.size()){
		std::cerr << "target cannot be bigger that original" << std::endl;
		return -1;
	}
	else if(video2.size() != 0){
		
	}
	else{
		return -1;
	}
	/////NORMALIZED		
	
	//PA3 Distance Calc
	//Find the distance between Frames
	if(video1.size() < 1){
		std::cerr << "Need more than zero frame to compute distance" << std::endl;
		return -1;
	}
	else if(video2.size() < 1){
		std::cerr << "Need more than zero frame to compute distance" << std::endl;
		return -1;
	}

	//PA6 use functio distance calc to to the required calc
	vector<vector<double> > tableVec;
	
	if(argString != "avg" && argString != "med" && argString != "Linf" && argString != "L2"){
		std::cerr << "Invalid arg, got:" << argString << std::endl;
		return -1;
	}
	else{
		tableVec = distanceCalc(argString, video1, video2);
	}
	
	Table myTable(tableVec);

	double min;

	for(int i = 0; i < myTable.size()-1; i++){
		 min = myTable[i][0];
		for(unsigned int j = 0; j < myTable[i+1].size(); j++){
			for(unsigned int k = 0; k <= j; k++){
				//cout << "MIN: " <<  min << "    i: " << i <<  "    k: " << k<<  std::endl;
				if(myTable[i][k] < min){
					min = myTable[i][k];
				}
			}
			myTable.add(i+1,j,min);
		}
	}
	
	//cout << vectorMin(myTable[myTable.size()-1]) << std::endl;
	resultsVector.push_back(vectorMin(myTable[myTable.size()-1]));

	//cout << vectorMin(resultsVector) << std::endl;
	
	if (inFile.bad()) {
		// IO error
		std::cerr << "IO error" << std::endl;
		return -1;
	}
	else if (!inFile.eof()) {
		// format error (not possible with getline but possible with operator>>)
		std::cerr << "Format error" << std::endl;
		return -1;
	}
	else if(inFile.eof()) {
		//end of file
		//std::cerr << "End of file, " << getLineCount << " lines read.\n"<< std::endl;
	}
	inFile.close();	
	
}
	

	
	//std::cout << "Time: " << (std::clock() - start) / (double)(CLOCKS_PER_SEC / 1000) << " ms" << std::endl;
	return 0;
}
//END OF MAIN
/////////
////////////////////
//////////////////
////////////////////
int indexOfMin(double min, vector<double>& results){
	int index = 0;
	for(unsigned int i = 0; i < results.size(); i ++){
		if(results[i] == min){
			index = i;
		}
	}
	return index;
}


vector<vector<double> > distanceCalc(string arg, FullVideo& video1, FullVideo& video2){
	vector<vector<double> > tabVec;
	
	if(arg == "avg"){
		//determine which file is longer, then compare and output	
		if(video1.size() < video2.size() || video1.size() == video2.size()){
			for(int i = 0; i  < video1.size(); i++){
			vector<Point3D> frame = (video1.get(i)).retVector();
			vector<double> doubVec;
				for(int j = 0; j  < video2.size(); j++){
					vector<Point3D> frame2 = (video2.get(j)).retVector();
					double retDouble = frameDistance(frame, frame2);
					doubVec.push_back(retDouble/25);
				}
				tabVec.push_back(doubVec);
			}
		}
		else if(video1.size() > video2.size()){				
			for(int i = 0; i  < video2.size(); i++){
			vector<Point3D> frame = (video2.get(i)).retVector();
			vector<double> doubVec;
				for(int j = 0; j  < video1.size(); j++){
					vector<Point3D> frame2 = (video1.get(j)).retVector();
					double retDouble = frameDistance(frame, frame2);
					doubVec.push_back(retDouble/25);
				}
			tabVec.push_back(doubVec);
			}
		}		
		return tabVec;
	}
	
	else if(arg == "med"){
			//determine which file is longer, then compare and output	
		if(video1.size() < video2.size() || video1.size() == video2.size()){
			for(int i = 0; i  < video1.size(); i++){
			vector<Point3D> frame = (video1.get(i)).retVector();
			vector<double> doubVec;
				for(int j = 0; j  < video2.size(); j++){
					vector<Point3D> frame2 = (video2.get(j)).retVector();
					double retDouble = medDistance(frame, frame2);
					doubVec.push_back(retDouble);
				}
				tabVec.push_back(doubVec);
			}
		}
		else if(video1.size() > video2.size()){						
			double count;
		for(int i = 0; i  < video2.size(); i++){
			vector<Point3D> frame = (video2.get(i)).retVector();
			vector<double> doubVec;
				for(int j = 0; j  < video1.size(); j++){
					vector<Point3D> frame2 = (video1.get(j)).retVector();
					double retDouble = medDistance(frame, frame2);
					doubVec.push_back(retDouble);
					count += retDouble;
				}
			tabVec.push_back(doubVec);
			}
		}	
		
		return tabVec;
	}

	else if(arg == "Linf"){
		//determine which file is longer, then compare and output	
		if(video1.size() < video2.size() || video1.size() == video2.size()){
			for(int i = 0; i  < video1.size(); i++){
			vector<Point3D> frame = (video1.get(i)).retVector();
			vector<double> doubVec;
				for(int j = 0; j  < video2.size(); j++){
					vector<Point3D> frame2 = (video2.get(j)).retVector();
					double retDouble = maxDistance(frame, frame2);
					doubVec.push_back(retDouble);
				}
				tabVec.push_back(doubVec);
			}
		}
		else if(video1.size() > video2.size()){						
			double count;
		for(int i = 0; i  < video2.size(); i++){
			vector<Point3D> frame = (video2.get(i)).retVector();
			vector<double> doubVec;
				for(int j = 0; j  < video1.size(); j++){
					vector<Point3D> frame2 = (video1.get(j)).retVector();
					double retDouble = maxDistance(frame, frame2);
					doubVec.push_back(retDouble);
					count += retDouble;
				}
			tabVec.push_back(doubVec);
			}
		}	
		
		return tabVec;
	}

	else if(arg == "L2"){
		//determine which file is longer, then compare and output	
		if(video1.size() < video2.size() || video1.size() == video2.size()){
			for(int i = 0; i  < video1.size(); i++){
			vector<Point3D> frame = (video1.get(i)).retVector();
			vector<double> doubVec;
				for(int j = 0; j  < video2.size(); j++){
					vector<Point3D> frame2 = (video2.get(j)).retVector();
					double retDouble = squaredDistance(frame, frame2);
					doubVec.push_back(sqrt(retDouble));
				}
				tabVec.push_back(doubVec);
			}
		}
		else if(video1.size() > video2.size()){				
			for(int i = 0; i  < video2.size(); i++){
			vector<Point3D> frame = (video2.get(i)).retVector();
			vector<double> doubVec;
				for(int j = 0; j  < video1.size(); j++){
					vector<Point3D> frame2 = (video1.get(j)).retVector();
					double retDouble = squaredDistance(frame, frame2);
					doubVec.push_back(sqrt(retDouble));
				}
			tabVec.push_back(doubVec);
			}
		}		
		return tabVec;
	}

	else{
		return tabVec;
	}
}
////////////////////////////////////////
double frameDistance(vector<Point3D>& frame, vector<Point3D>& frame2){
	double dist = 0;
	for(unsigned int i = 0; i  < frame.size(); i++){			
		double deltaX = (frame[i].X() - frame2[i].X());
		double deltaY = (frame[i].Y() - frame2[i].Y());
		double deltaZ = (frame[i].Z() - frame2[i].Z());	
		dist += sqrt((deltaX * deltaX) + (deltaY * deltaY) + (deltaZ * deltaZ));
	}
	//cout <<dist<<std::endl;
	return dist;
}

double squaredDistance(vector<Point3D>& frame, vector<Point3D>& frame2){
	double dist = 0;
	for(unsigned int i = 0; i  < frame.size(); i++){			
		double deltaX = (frame[i].X() - frame2[i].X());
		double deltaY = (frame[i].Y() - frame2[i].Y());
		double deltaZ = (frame[i].Z() - frame2[i].Z());	
		dist += (deltaX * deltaX) + (deltaY * deltaY) + (deltaZ * deltaZ);
	}
	return dist;
}

double medDistance(vector<Point3D>& frame, vector<Point3D>& frame2){
	vector<double> distVec;
	for(unsigned int i = 0; i  < frame.size(); i++){	
		double dist = 0;		
		double deltaX = (frame[i].X() - frame2[i].X());
		double deltaY = (frame[i].Y() - frame2[i].Y());
		double deltaZ = (frame[i].Z() - frame2[i].Z());	
		dist = sqrt((deltaX * deltaX) + (deltaY * deltaY) + (deltaZ * deltaZ));
		//cout << dist << std::endl;
		distVec.push_back(dist);
	}
	sort(distVec.begin(), distVec.end());

	return distVec[12];
}

double maxDistance(vector<Point3D>& frame, vector<Point3D>& frame2){
	vector<double> distVec;
	for(unsigned int i = 0; i  < frame.size(); i++){	
		double dist = 0;		
		double deltaX = (frame[i].X() - frame2[i].X());
		double deltaY = (frame[i].Y() - frame2[i].Y());
		double deltaZ = (frame[i].Z() - frame2[i].Z());	
		dist = sqrt((deltaX * deltaX) + (deltaY * deltaY) + (deltaZ * deltaZ));
		//cout << dist << std::endl;
		distVec.push_back(dist);
	}
	sort(distVec.begin(), distVec.end());

	return distVec[24];
}

///////////////////////////////////
double vectorMin(vector<double>& passed){
	double min = passed[0];
	for(unsigned int i = 0; i < passed.size(); i++){
		if(passed[i] < min){
			min = passed[i];
		}
	}
	return min;
}

FullVideo normalizeFile(ifstream& myFile){	
	///////////////////////////////		
	string line;
	double max = 0;
	vector<double> position(75);
	vector<Point3D> point3DVector(25);
	vector<Frame> fullVideo;		
	double xAvg = 0; 
	double yAvg = 0;
	double zAvg = 0;
	int getLineCount = 0;
	
	while (getline(myFile, line)) {
			//create vector to store the 75 doubles
			double passToVector;
			//count to make sure there are exactly 75 doubles
			int count = 0;
			//increment counter to keep track of how many lines I read
			++getLineCount;
			//string stream to read the data from
			std::istringstream lineString(line);
			//begin reading and storing the doubles
			
			if(line == ""){
				if(getline(myFile, line).eof()){
				
				}
				else{
				std::cerr << "Found an empty line on  : " << getLineCount << std::endl;
				FullVideo myVideo;
				return myVideo;
				}
			}
					
			while (lineString >> passToVector) {
				if (lineString.fail()) {
					lineString.clear();
					std::cerr << "Unsupported datatype detected.\n";
					FullVideo myVideo;
					return myVideo;
				}
				else {
					position.push_back(passToVector);
					++count;
				}
			}
			//count should be 75 after reading each point from the line and storing it into the vector		
			//cout << count;
			if (count != 75 && !line.empty()) {
				//cout << count;
				std::cerr << "You must pass exactly 75 doubles, Data at point: " << count << ".  On line number: " 					<< getLineCount << " is unsupported or illegal\n" << std::endl;
				position.clear();
				FullVideo myVideo;
				return myVideo;
			}
			
			//PA2 ALLIGN SPINE TO (0,0,0)			
			xAvg += position[0];
			yAvg += position[1];
			zAvg += position[2];


			//Pass the Vector to point3D then to PoseDisplay!!!
			//All test code for the time being/////////////////////////////////////////
			for(int i = 0; i < 75; i++){
				Point3D test(position[i], position[i+1], position[i+2]);
				point3DVector.push_back(test);
				i = i + 2;
				//std::cerr << "ERROR in pushing to Point3D vector" << std::endl;	
			}
			
			Frame myFrame(point3DVector);
			fullVideo.push_back(myFrame);

			//clear both the point3d vector and the points vector for the next loop
			point3DVector.clear();
			position.clear();
	}
	
	//Spine allign
	xAvg = xAvg/getLineCount;
	yAvg = yAvg/getLineCount;
	zAvg = zAvg/getLineCount;
	//got Averages for the spine, now subtract all points by them
	for(unsigned int i = 0; i  < fullVideo.size(); i++){
		fullVideo[i].spineFix(xAvg,yAvg,zAvg);
	}
	//end spine allign
	
	for(unsigned int i = 0; i  < fullVideo.size(); i++){
		double temp = fullVideo[i].maxFrame();
		if(temp > max){
			max = temp;
		}
	}
	//cout<< "LINECOUNT: " << getLineCount << std::endl;
	if(getLineCount == 0){
		std::cerr << "Cannot have an empty file, must be at least 1 line!" << std::endl;
		FullVideo myVideo;
		return myVideo;
	}
	//test is max = 0. cant normalize
	if(max == 0){
		std::cerr << "Max cannot = 0. Impossible to normalize" << std::endl;
		FullVideo myVideo;
		return myVideo;
	}
	
	//Max calculated, now scale all other points.
	double scale;
	//cout << "Max: " << max << std::endl;	
	if(max < 1){
		scale = (1/max);
	}else{
		scale = (1/max);
	}
	for(unsigned int i = 0; i  < fullVideo.size(); i++){
		fullVideo[i].reScale(scale);
	}
	FullVideo myVideo = FullVideo(fullVideo, getLineCount);
	return myVideo;
}





