// CS253_P1.cpp : Defines the entry point for the console application.
//
#include <Point3D.h>
//#include <PoseDisplay.h>
#include <Frame.h>
#include <FullVideo.h>
#include <Table.h>
//#include <stdafx.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <iterator>
#include <math.h>
#include <stdlib.h>
using std::string;
using std::cout;
using std::istream;
using std::ifstream;
using std::ostream;
using std::ofstream;
using std::vector;
#include <ctime>
double vectorMin(vector<double> passed);
double frameDistance(vector<Point3D> frame, vector<Point3D> frame2);
FullVideo normalizeFile(ifstream& myFile);

int main(int argc, char* argv[])
{

	//std::clock_t    start;
	//start = std::clock();

	//FILE I/O/////////////////////////////////////////////////////////////
	// check for the correct number of arguments
	ifstream inFile;
	ifstream secondInFile;
	//ofstream outFile;
	if (argc == 3) {
		inFile.open(argv[1]);
		secondInFile.open(argv[2]);
		//outFile.open(argv[3]);
	}
	else {
		std::cerr << "Usage: InputFile.txt InputFile.txt" << std::endl;
		return -1;
	}

	//check if inFile exists and is openable
	if (inFile.is_open()) {
		//Testing purposes only
		//cout << "File is open.\n";
	}
	else {
		std::cerr << "Cannot Open file.\n";
		return -1;
	}
	
	//check if inFile exists and is openable
	if (secondInFile.is_open()) {
		//Testing purposes only
		//cout << "File is open.\n";
	}
	else {
		std::cerr << "Cannot Open file.\n";
		return -1;
	}

    /*//check if outFile exists and is openable
	if (outFile.is_open()) {
		//test wrriting to file... erase in final.
		//outFile << "Wrinting this to the file\n";
		//outFile.close();
	}
	else {
		std::cerr << "Cannot Open Output file.\n";
		return -1;
	}*/
	//////////////////////////////////////////////////////////////////////
	//Finished File I/O, now parse line by line and store doubles into vector
	//POINTER YOU MUST DELETE
	FullVideo video1 = normalizeFile(inFile);
	
	if(video1.size() != 0){
		
	}
	else{
		return -1;
	}
	FullVideo video2 = normalizeFile(secondInFile);
	if(video2.size() != 0){
		
	}
	else{
		return -1;
	}
	/////NORMALIZED		
	
	//PA3 Distance Calc
	//Find the distance between Frames
	if(video1.size() < 1){
		std::cerr << "Need more than zero frame to compute distance" << std::endl;
		return -1;
	}
	else if(video2.size() < 1){
		std::cerr << "Need more than zero frame to compute distance" << std::endl;
		return -1;
	}

	//create a table object to store results
	vector<vector<double> > tabVec;
	
	//determine which file is longer, then compare and output	
	if(video1.size() < video2.size() || video1.size() == video2.size()){
		for(int i = 0; i  < video1.size(); i++){
		vector<Point3D> frame = (video1.get(i)).retVector();
		vector<double> doubVec;
			for(int j = 0; j  < video2.size(); j++){
				vector<Point3D> frame2 = (video2.get(j)).retVector();
				double retDouble = frameDistance(frame, frame2);
				doubVec.push_back(retDouble);
			}
			tabVec.push_back(doubVec);
		}
	}
	else if(video1.size() > video2.size()){				
		for(int i = 0; i  < video2.size(); i++){
		vector<Point3D> frame = (video2.get(i)).retVector();
		vector<double> doubVec;
			for(int j = 0; j  < video1.size(); j++){
				vector<Point3D> frame2 = (video1.get(j)).retVector();
				double retDouble = frameDistance(frame, frame2);
				doubVec.push_back(retDouble);
		}
		tabVec.push_back(doubVec);
		}
	}
			
	Table myTable(tabVec);
	//pre-table print to cout
	/*for(int i = 0; i < myTable.size(); i++){
				vector<double> dVec = myTable[i];
				for(unsigned int j = 0; j < dVec.size(); j++){
					cout << dVec[j] << " ";
				}
					cout << "\n";
	}*/

	double min;

	for(int i = 0; i < myTable.size()-1; i++){
		 min = myTable[i][0];
		for(unsigned int j = 0; j < myTable[i+1].size(); j++){
			for(unsigned int k = 0; k <= j; k++){
				//cout << "MIN: " <<  min << "    i: " << i <<  "    k: " << k<<  std::endl;
				if(myTable[i][k] < min){
					min = myTable[i][k];
				}
			}
			myTable.add(i+1,j,min);
		}
	}

	cout << vectorMin(myTable[myTable.size()-1]) << std::endl;

	/*//table print
	for(int i = 0; i < myTable.size(); i++){
				vector<double> dVec = myTable[i];
				for(unsigned int j = 0; j < dVec.size(); j++){
					outFile << dVec[j] << " ";
				}
					outFile << "\n";
	}*/
	
	if (inFile.bad()) {
		// IO error
		std::cerr << "IO error" << std::endl;
		return -1;
	}
	else if (!inFile.eof()) {
		// format error (not possible with getline but possible with operator>>)
		std::cerr << "Format error" << std::endl;
		return -1;
	}
	else if(inFile.eof()) {
		//end of file
		//std::cerr << "End of file, " << getLineCount << " lines read.\n"<< std::endl;
	}


	inFile.close();
	//outFile.close();

	//std::cout << "Time: " << (std::clock() - start) / (double)(CLOCKS_PER_SEC / 1000) << " ms" << std::endl;
	return 0;
}


double vectorMin(vector<double> passed){
	double min = passed[0];
	for(unsigned int i = 0; i < passed.size(); i++){
		if(passed[i] < min){
			min = passed[i];
		}
	}
	return min;
}

FullVideo normalizeFile(ifstream& myFile){	
	///////////////////////////////		
	string line;
	double max = 0;
	vector<double> position;
	vector<Point3D> point3DVector;
	vector<Frame> fullVideo;		
	double xAvg = 0; 
	double yAvg = 0;
	double zAvg = 0;
	int getLineCount = 0;
	
	while (getline(myFile, line)) {
			//create vector to store the 75 doubles
			double passToVector;
			//count to make sure there are exactly 75 doubles
			int count = 0;
			//increment counter to keep track of how many lines I read
			++getLineCount;
			//string stream to read the data from
			std::istringstream lineString(line);
			//begin reading and storing the doubles
			
			if(line == ""){
				if(getline(myFile, line).eof()){
				
				}
				else{
				std::cerr << "Found an empty line on  : " << getLineCount << std::endl;
				FullVideo myVideo;
				return myVideo;
				}
			}
					
			while (lineString >> passToVector) {
				if (lineString.fail()) {
					lineString.clear();
					std::cerr << "Unsupported datatype detected.\n";
					FullVideo myVideo;
					return myVideo;
				}
				else {
					position.push_back(passToVector);
					++count;
				}
			}
			//count should be 75 after reading each point from the line and storing it into the vector		
			//cout << count;
			if (count != 75 && !line.empty()) {
				//cout << count;
				std::cerr << "You must pass exactly 75 doubles, Data at point: " << count << ".  On line number: " 					<< getLineCount << " is unsupported or illegal\n" << std::endl;
				position.clear();
				FullVideo myVideo;
				return myVideo;
			}
			
			//PA2 ALLIGN SPINE TO (0,0,0)			
			xAvg += position[0];
			yAvg += position[1];
			zAvg += position[2];


			//Pass the Vector to point3D then to PoseDisplay!!!
			//All test code for the time being/////////////////////////////////////////
			for(int i = 0; i < 75; i++){
				Point3D test(position[i], position[i+1], position[i+2]);
				point3DVector.push_back(test);
				i = i + 2;
				//std::cerr << "ERROR in pushing to Point3D vector" << std::endl;	
			}
			
			Frame myFrame(point3DVector);
			fullVideo.push_back(myFrame);

			//clear both the point3d vector and the points vector for the next loop
			point3DVector.clear();
			position.clear();
	}
	
	//Spine allign
	xAvg = xAvg/getLineCount;
	yAvg = yAvg/getLineCount;
	zAvg = zAvg/getLineCount;
	//got Averages for the spine, now subtract all points by them
	for(unsigned int i = 0; i  < fullVideo.size(); i++){
		fullVideo[i].spineFix(xAvg,yAvg,zAvg);
	}
	//end spine allign
	
	for(unsigned int i = 0; i  < fullVideo.size(); i++){
		double temp = fullVideo[i].maxFrame();
		if(temp > max){
			max = temp;
		}
	}
	//cout<< "LINECOUNT: " << getLineCount << std::endl;
	if(getLineCount == 0){
		std::cerr << "Cannot have an empty file, must be at least 1 line!" << std::endl;
		FullVideo myVideo;
		return myVideo;
	}
	//test is max = 0. cant normalize
	if(max == 0){
		std::cerr << "Max cannot = 0. Impossible to normalize" << std::endl;
		FullVideo myVideo;
		return myVideo;
	}
	
	//Max calculated, now scale all other points.
	double scale;
	//cout << "Max: " << max << std::endl;	
	if(max < 1){
		scale = (1/max);
	}else{
		scale = (1/max);
	}
	for(unsigned int i = 0; i  < fullVideo.size(); i++){
		fullVideo[i].reScale(scale);
	}
	FullVideo myVideo = FullVideo(fullVideo, getLineCount);
	return myVideo;
}



double frameDistance(vector<Point3D> frame, vector<Point3D> frame2){
	double dist = 0;
	for(unsigned int i = 0; i  < frame.size(); i++){			
		double deltaX = (frame[i].X() - frame2[i].X());
		double deltaY = (frame[i].Y() - frame2[i].Y());
		double deltaZ = (frame[i].Z() - frame2[i].Z());	
		dist += sqrt((deltaX * deltaX) + (deltaY * deltaY) + (deltaZ * deltaZ));
	}
	return dist;
}



